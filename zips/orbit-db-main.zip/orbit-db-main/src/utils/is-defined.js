'use strict'

const isDefined = (arg) => arg !== undefined && arg !== null

module.exports = isDefined
