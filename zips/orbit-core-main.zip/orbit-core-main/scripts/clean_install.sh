#!/bin/sh
rm -rf ./node_modules/ipfs/node_modules/ipfs-api
rm -rf ./node_modules/ipfsd-ctl/node_modules/go-ipfs-dep
rm -rf ./node_modules/ipfsd-ctl/node_modules/ipfs-api
