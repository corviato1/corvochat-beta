// http://patorjk.com/software/taag/#p=display&f=Georgia11&t=Orbit

module.exports = `
                        ,,        ,,
    .g8""8q.           *MM        db   mm
  .dP'    \`YM.          MM             MM
  dM'      \`MM \`7Mb,od8 MM,dMMb.\`7MM mmMMmm
  MM        MM   MM' "' MM    \`Mb MM   MM
  MM.      ,MP   MM     MM     M8 MM   MM
  \`Mb.    ,dP'   MM     MM.   ,M9 MM   MM
    \`"bmmd"'   .JMML.   P^YbmdP'.JMML. \`Mbmo

`
