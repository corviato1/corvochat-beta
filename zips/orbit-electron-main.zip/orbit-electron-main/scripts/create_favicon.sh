#!/bin/sh
convert assets/OrbitLogo_32x32.png client/src/favicon.ico