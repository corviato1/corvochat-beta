import en from './en'
import fi from './fi'
import pt from './pt'
import zh from './zh'

export default {
  en,
  fi,
  pt,
  zh
}
