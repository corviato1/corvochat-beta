import translation from './translation.json'
import dateLocale from 'date-fns/locale/zh-CN'

export default { translation, dateLocale }
