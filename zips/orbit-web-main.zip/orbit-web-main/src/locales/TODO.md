# Localisation TODO

en

-

fi

-

pt

-

zh

- `channel.showingLast`
- `channel.showingLast_plural`
- `settings.names.messageNotifications`
- `settings.options.messageNotifications`
