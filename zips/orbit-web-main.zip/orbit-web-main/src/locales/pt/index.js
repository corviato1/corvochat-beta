import translation from './translation.json'
import dateLocale from 'date-fns/locale/pt'

export default { translation, dateLocale }
