import translation from './translation.json'
import dateLocale from 'date-fns/locale/en-US'

export default { translation, dateLocale }
