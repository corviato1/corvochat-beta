import translation from './translation.json'
import dateLocale from 'date-fns/locale/en'

export default { translation, dateLocale }
