import translation from './translation.json'
import dateLocale from 'date-fns/locale/fi'

export default { translation, dateLocale }
