# Fonts

Fonts from: 
https://github.com/google/fonts

Converted to woff2 format with: 
https://www.npmjs.com/package/ttf2woff2
