'use strict'

import React from 'react'

export default React.createContext()
